﻿using Microsoft.EntityFrameworkCore;
using zh_gyakorlas.Models;

namespace zh_gyakorlas.Context
{
    public class EFContext : DbContext
    {
        public virtual DbSet<Kategoria> Kategoria { get; set; }

        public virtual DbSet<KisAllat> KisAllat { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlite("Data Source=.//DB//allatok.db");
        }
    }
}
