﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using zh_gyakorlas.Context;
using zh_gyakorlas.Models;

namespace zh_gyakorlas.Controllers
{
    public class KisAllatsController : Controller
    {
        private readonly EFContext _context;

        public KisAllatsController(EFContext context)
        {
            _context = context;
        }

        // GET: KisAllats
        public async Task<IActionResult> Index()
        {
            var eFContext = _context.KisAllat.Include(k => k.ReferencedKateg);
            return View(await eFContext.ToListAsync());
        }

        // GET: KisAllats/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var kisAllat = await _context.KisAllat
                .Include(k => k.ReferencedKateg)
                .FirstOrDefaultAsync(m => m.ID == id);
            if (kisAllat == null)
            {
                return NotFound();
            }

            return View(kisAllat);
        }

        // GET: KisAllats/Create
        public IActionResult Create()
        {
            ViewData["KategoriaId"] = new SelectList(_context.Kategoria, "ID", "Name");
            return View();
        }

        // POST: KisAllats/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("ID,Name,Age,Weight,Image,KategoriaId")] KisAllat kisAllat)
        {
            if (ModelState.IsValid)
            {
                _context.Add(kisAllat);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["KategoriaId"] = new SelectList(_context.Kategoria, "ID", "Name", kisAllat.KategoriaId);
            return View(kisAllat);
        }

        // GET: KisAllats/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var kisAllat = await _context.KisAllat.FindAsync(id);
            if (kisAllat == null)
            {
                return NotFound();
            }
            ViewData["KategoriaId"] = new SelectList(_context.Kategoria, "ID", "Name", kisAllat.KategoriaId);
            return View(kisAllat);
        }

        // POST: KisAllats/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("ID,Name,Age,Weight,Image,KategoriaId")] KisAllat kisAllat)
        {
            if (id != kisAllat.ID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(kisAllat);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!KisAllatExists(kisAllat.ID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["KategoriaId"] = new SelectList(_context.Kategoria, "ID", "Name", kisAllat.KategoriaId);
            return View(kisAllat);
        }

        // GET: KisAllats/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var kisAllat = await _context.KisAllat
                .Include(k => k.ReferencedKateg)
                .FirstOrDefaultAsync(m => m.ID == id);
            if (kisAllat == null)
            {
                return NotFound();
            }

            return View(kisAllat);
        }

        // POST: KisAllats/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var kisAllat = await _context.KisAllat.FindAsync(id);
            if (kisAllat != null)
            {
                _context.KisAllat.Remove(kisAllat);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool KisAllatExists(int id)
        {
            return _context.KisAllat.Any(e => e.ID == id);
        }
    }
}
