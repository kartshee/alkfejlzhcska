﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace zh_gyakorlas.Models
{
    public class KisAllat
    {
        [Key]
        public int ID { get; set; }

        [Required]
        public string Name { get; set; }

        [Required]
        [Range(0, int.MaxValue)]
        public string Age { get; set; }

        [Required]
        [Range(0, double.MaxValue)]
        public double Weight { get; set; }

        [Required]
        [RegularExpression(@".*\.(png|jpg)$", ErrorMessage = "Csak .png vagy .jpg lehet.")]
        public string Image { get; set; }

        [Required]
        [ForeignKey("ReferencedKateg")]
        public int KategoriaId { get; set; }

        public virtual Kategoria? ReferencedKateg { get; set; }
    }
}
