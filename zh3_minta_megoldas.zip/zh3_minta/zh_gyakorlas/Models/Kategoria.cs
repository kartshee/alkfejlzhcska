﻿using System.ComponentModel.DataAnnotations;
using System.Drawing;

namespace zh_gyakorlas.Models
{
    public class Kategoria
    {
        [Key]
        public int ID { get; set; }

        [Required]
        public string Name { get; set; }

        [Required]
        public string Description { get; set; }
    }
}
